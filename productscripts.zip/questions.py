"""
Generate the questions pages
Latex model is questioncards.txt

"""

import sys
import os

framewidth = 10
width = 8
height = 10

row_dis = width + 1

col_dis = height + 1

colors = ['red!10', 'green!10', 'blue!10', 'orange!10', 'pink!10']


def get_data(path, filename):
	pics = []
	questions = []

	for filename in os.listdir(path):
		if '.jpg' in filename or 'jpeg' in filename or '.png' in filename:
			pics.append(filename)

	
	with open(os.path.join(path, filename), 'r') as f:
		for line in f.readlines():
			print(line)
			if len(line.strip()) > 2:
				questions.append(line.strip())
	

	#questions = ["Should we care about what other people think?", "Do you are what other people think about you?" "Can someone else decide whether or not you are speical", "Why don\'t the gray dots or gold stars stick to Lucia?","Does Lucia care what the other Wemmicks think about her?","Writing Topic: Write an experience that you care about other people think."]

	output(questions, pics, path)


def output(questions, pics, path):

	row_count = int(21 / row_dis)

	col_count = int(28 / col_dis)

	begin = [framewidth/2.0 + 1, framewidth/2.0 + 1]

	with open('makequestioncards.txt', 'w+') as f:
		c = 0
		p = 0
		for i in range(0, len(questions)):

			if i % row_count == 0:

				if i != 0:
					begin[0] = framewidth / 2 + 1
					begin[1] += col_dis

			else:
				begin[0] += row_dis

			if i % (row_count * col_count) == 0:
				begin = [framewidth/2.0 + 1, framewidth/2.0 + 1]
				if i != 0:
					f.write('\\null\\newpage\n')
				f.write('\\thispagestyle{empty}\n')
				f.write('\\textblockorigin{0cm}{0cm}\n')
			f.write('\\begin{textblock*}{' + str(framewidth) + 'cm}('+ str(begin[0]) + 'cm,' + str(begin[1]) + 'cm)\n')

			f.write('\\drawcontent{' + questions[i] + '}{' + os.path.join(path, pics[p]) + '}{' + colors[c] + '}\n')

			c += 1
			if c == len(colors):
				c = 0

			p += 1
			if p == len(pics):
				p = 0

			f.write('\end{textblock*}\n')


def main():
	get_data('/Users/lxb/Documents/yyc/scripts/booksproject/millonscat/', 'questions.txt')


if __name__ == '__main__':
	main()



















