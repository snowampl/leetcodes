"""
Generate the bookmarks for products
Latex model is bookmark.tex
"""

import os
import sys

width = 14
height = 4

row_dis = height + 1

count = int( 28 / (row_dis + 1) )

def draw_bookmark(width, height, color):
	r_string = ''
	begin = (-1 * width/2, height/2)
	r_string += '\\filldraw[fill=' + color+'](' + str(begin[0]) + 'cm,' + str(begin[1]) + 'cm) arc('
	r_string += '90:270:' + str(height/2) + ');\n'

	r_string += '\\filldraw[color =' + color + '] (' + str(begin[0]) + 'cm,' + str(-1*begin[1]) + 'cm) --'
	r_string +='(' + str(-1 *begin[0]) + 'cm,' + str(-1*begin[1]) + 'cm) --'
	r_string +='(' + str(-1 *begin[0]) + 'cm,' + str(begin[1]) + 'cm) --'
	r_string +='(' + str(begin[0]) + 'cm,' + str(begin[1]) + 'cm);\n'

	r_string += '\\filldraw[fill=' + color+'](' + str(-1 * begin[0]) + 'cm,' + str(-1 * begin[1]) + 'cm) arc('
	r_string += '-90:90:' + str(height/2) + ');\n'
	
	r_string += '\\draw(' + str(begin[0]) +'cm,' + str(begin[1]) + 'cm) --'
	r_string +='(' + str(-1 *begin[0]) + 'cm,' + str(begin[1]) + 'cm);\n '

	r_string += '\\draw(' + str(begin[0]) +'cm,' + str(-1 * begin[1]) + 'cm) --'
	r_string +='(' + str(-1 *begin[0]) + 'cm,' + str(-1 * begin[1]) + 'cm);\n '

	return(r_string)


def read_data(path, filename):
	pics = []
	proverbs = []

	colors = ['red!10', 'yellow!10', 'blue!10', 'pink!10', 'orange!10']

	with open(os.path.join(path, filename), 'r' ) as f:
		for line in f.readlines():
			if len(line) > 2:
				proverbs.append(line.strip())

	for fname in os.listdir(path):
		if 'jpg' in fname or 'jpeg' in fname or 'png' in fname:
			pics.append(os.path.join(path, fname))


	

	begin = [10, 6]

	p = 0
	c = 0
	with open('makebookmarks.txt', 'w+') as f:
		f.write('\\thispagestyle{empty}\n')
		for i in range(0, len(proverbs)):
			r_string = draw_bookmark(14, 4, colors[c])
			if i % count == 0:
				if i != 0:
					f.write('\\null\\newpage\n')
					f.write('\\thispagestyle{empty}\n')
					f.write('\\textblockorigin{0cm}{0cm}\n')
					begin[1] = 6

			f.write('\\begin{textblock*}{'+ str(width+2) + 'cm}(' + str(begin[0]) + 'cm,' + str(begin[1]) + 'cm)\n')
			f.write('\\begin{tikzpicture}[overlay]\n')
			f.write(r_string)
			f.write('\drawcontent{'+ proverbs[i] + '}{' + pics[p] + '};\n' )
			p += 1
			if p == len(pics):
				p = 0
			c += 1
			if c == len(colors):
				c = 0

			f.write('\end{tikzpicture}\n')
			f.write('\end{textblock*}\n')
			begin[1] += row_dis

def main():
	read_data('/Users/lxb/Documents/yyc/scripts/spring/springtopic/', 'proverb.txt')


if __name__ == '__main__':
	main()



